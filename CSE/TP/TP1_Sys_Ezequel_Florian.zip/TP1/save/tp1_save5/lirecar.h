/*
 * lirecar(m,c) : affiche m sur stdout,
 * lit un caractere au clavier et l'affiche sur stdout,
 * sans attendre la frappe de return.
 */


void lirecar(char * Message, char * car);

