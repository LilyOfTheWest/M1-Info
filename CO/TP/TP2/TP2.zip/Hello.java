/* Hello: affiche "Hello World !*/ 
 
public class Hello { 
    public static void main ( String [] arg){ 
 
 System.out.println("Hello World!"); 
    } 
} 
