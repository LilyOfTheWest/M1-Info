/* tri a bulle*/ 
public class Tri { 
    	public static void bulle (int [] tab){ 
		int tmp;

		for (int i=tab.length-1; i > 0; i--) {
			for (int j=0; j < i; j++) {
				if (tab[j] > tab[j+1]) {
					tmp = tab[j];
					tab[j] = tab[j+1];
					tab[j+1] = tmp;
				}
			}
		}
    	} 
   
    	public static void main (String [] arg){ 
		int t[] = {2,3,7,5,6,11,0}; 
		System.out.println("Avant"); 
		for (int i=0; i<t.length; i++){ 
			System.out.println(t[i] + " "); 
		} 
		System.out.println("Apres"); 
		Tri.bulle(t);
		for (int i=0; i<t.length; i++){ 
			System.out.println(t[i] + " "); 
 		} 
    	}
} 
