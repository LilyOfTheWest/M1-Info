import java.util.ArrayList;

public class Pascal {
	public static void main(String[] args) {
		ArrayList<Integer[]> liste = new ArrayList<Integer[]>();
		int N = Integer.parseInt(args[0]);
		
		for(int i=1; i <= N; i++) {
			liste.add(new Integer[i]);
		}

		for(int i=0; i < N; i++) {
			for(int j=0; j < i+1; j++) {
				if (j == 0 || j == i) {
					liste.get(i)[j] = 1;
				} else {
					liste.get(i)[j] = liste.get(i-1)[j-1] + liste.get(i-1)[j];
				}
			}
		}

		for(Integer[] i : liste) {
			for(int j=0; j < i.length; j++) {
				System.out.print(i[j] + " ");
			}
			System.out.println();
		}
	}
}
