public class Exo5 {
	public static void main(String[] args) {
		int N = Integer.parseInt(args[0]);
		boolean[] tab = new boolean[N];
		
		for (int i=2; i < N; i++) {
			tab[i] = true;
			for(int j=2; j < i; j++) {
				if (i%j == 0)
					tab[i] = false;
			}
		}

		for (int i=2; i < N; i++) {
			if (tab[i])
				System.out.print(i + " ");
		}
		System.out.println();
	}
}
