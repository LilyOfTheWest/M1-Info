public class Palindrome {
	public static void main(String[] args) {
		String mot = args[0];
		boolean test = true;

		for(int i=0; i < mot.length()/2; i++) {
			if (mot.charAt(i) != mot.charAt(mot.length()-1-i))
				test = false;
		}

		if (test)
			System.out.println(mot + " est un palindrome !");
		else
			System.out.println(mot + " n'est pas un palindrome !");
	}
}
