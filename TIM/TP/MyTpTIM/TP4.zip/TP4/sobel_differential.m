function [pic_x,pic_y,pic_norm] = sobel_differential(pic)
%function [pic_x,pic_y,pic_norm] = sobel_differential(pic)
%
% Calculate Sobel Filtering
%
%
% INTPUT: 
%         pic: original picture in uint8
% OUTPUT:
%         pic_x: differential in x
%         pic_y: differential in y
%         pic_norm: norm of the gradient
%


pic = double(pic);

%<to do !!!!!!!!>
%
% calculer les noyaux de convolution 2D � partir noyaux 1D S(binomial) et D(gradient)
% calculez pic_x, pic_y et la norme du gradient
%
%</to do>

