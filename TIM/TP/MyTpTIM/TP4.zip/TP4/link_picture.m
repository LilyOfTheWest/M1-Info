function edges_link = link_picture(edges_points, is_edges_points)
%function edges_link = link_picture(edge_points, is_edge_points)
%
% Perform a linkage function
%
% INPUT: 
%       edges_points: binary picture of  edge points
%       is_edges_points: binary picture of  candidate edge points
% 
% OUTPUT: 
%       edges_link: segmented edges after linkage
%
%

%size
[N_i,N_j] = size(edges_points);


%<to do !!!!!!!!!!!!!!>
%
%
% R�alisez les 4 passes vues en cours afin de completer edges_points.
% <gauche-droite> | <haut-bas> | <droite gauche> | <bas-haut>
%    
% %1ere passage
% for(k_i=...)
%   for(k_j=...)
%
% 2eme passage
% for(k_j=...)
%   for(k_i=...)
%
% 3eme passage
% for(k_i=...)
%   for(k_j=...)
%
% 4eme passage
% for(k_j=...)
%   for(k_i=...)
%
%
%
%
%</to do>


